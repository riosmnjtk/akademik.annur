<div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Jenis Pembayaran</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="keluar.php">
                               Keluar
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
<!-- MAIN -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">
                                    <button type="button" class="btn btn-success pe-7s-add-user" data-toggle="modal" data-target="#tambahJenis"></i></button>
                                </h4>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table id="myTable" class="table table-hover table-striped">
                                    <thead>
                                        <th>No</th>
                                        <th>Id</th>
                                        <th>Nama</th>
                                        <th>Harga</th>
                                        <th>Tingkatan</th>
                                        <th width="200px">Action</th>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = "SELECT * FROM jenis_pembayaran ORDER BY id_jenis_bayar";
                                        $tampil = mysqli_query($connect,$query);
                                        $no = 1;
                                        while ($r = mysqli_fetch_array($tampil)){
                                            echo"
                                            <tr>
                                                <td>$no</td>
                                                <td>$r[id_jenis_bayar]</td>
                                                <td style='text-transform:capitalize'>$r[nm_jenis_bayar]</td>
                                                <td style='text-transform:capitalize'>$r[harga]</td>
                                                <td style='text-transform:capitalize'>$r[tingkatan]</td>
                                                <td> "; ?>
<!-- Button trigger modal -->
                                                <button type="button" class="btn btn-warning" value='<?php echo $r['id_jenis_bayar'];?>' onclick="ubahdata(this.value)" data-toggle="modal" data-target="#ubahGuru"><i class="glyphicon glyphicon-pencil"></i></button>&nbsp;
                                                <button type="button" class="btn btn-danger" value='<?php echo $r['id_jenis_bayar'];?>' onclick="hapusdata(this.value)" data-toggle="modal" data-target="#hapusGuru"><i class="pe-7s-trash"></i></button>
                                            </td>
                                        </tr>
                                        <?php
                                        $no++;}
                                        ?></tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- MODAL -->
  <!--****************** Tambah ******************-->
<div class="modal fade" id="tambahJenis" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Tambah Jenis</h4>
      </div>
      <div class="modal-body">
        <!-- general form elements -->
        <!-- form start -->
        <form role="form" method="POST" action="proses/prs_jenisbayar.php">
          <div class="box-body">

            <div class="form-group">
              <label>Nama Jenis Bayar</label>
              <input name="nm_jenis_bayar" type="text" class="form-control" placeholder="Masukkan Nama Guru" maxlength="50" required="" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Harga</label>
              <input name="harga" type="text" class="form-control" required="" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Tingkatan</label>
              <select name="tingkatan" class="form-control">
                <option value='belum memilih' selected>-- Pilih Tingkatan --</option>
                <option value="TK">TK</option>
                <option value="SD">SD</option>
                <option value="SMP">SMP</option>
              </select>
            </div>
            
            <!-- /.box-body --><br>
            <div class="box-footer">
              <button name="tambahJenis" type="submit" class="btn btn-primary">Tambah</button>
            </div>
          </div>
        </form>
        <!-- /.box -->
      </div>
    </div>
  </div>
</div>
<!--****************** Ubah ******************-->
<div class="modal fade" id="ubahJenis" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Ubah Jenis Bayar</h4>
      </div>
      <div class="modal-body">
        <!-- general form elements -->
          <!-- form start -->
          <form role="form" method="POST" action="proses/prs_jenisbayar.php">
            <div class="box-body">
              <!-- Ubah Data -->
              <span id="dub"></span>
              <!-- End Ubah Data -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <button name="ubahJenis" type="submit" class="btn btn-primary">Ubah</button>
            </div>
          </form>
        <!-- /.box -->
      </div>
    </div>
  </div>
</div>
<!-- MODAL HAPUS -->
        <div class="modal fade" id="hapusJenis" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Hapus Jenis Bayar</h4>
                        </div>
                    <div class="modal-body">
                        <!-- general form elements -->
                        <!-- form start -->
                        <form role="form" method="POST" action="proses/prs_guru.php">
                            <div class="box-body">
                                Yakin ingin menghapus data?
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer">
                                <input type="hidden" id="id_jenis_bayar" name="id_jenis_bayar">
                                <button name="hapusJenis" type="submit" class="btn btn-primary">Hapus</button>
                            </div>
                        </form>
                            <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
<script>
    function ubahdata(id_jenis_bayar){
    var ajaxbos = new XMLHttpRequest();
        ajaxbos.onreadystatechange= function(){
            if(ajaxbos.readyState==4 && ajaxbos.status==200){
                document.getElementById("dub").innerHTML= ajaxbos.responseText;
            }
        };
        ajaxbos.open("GET","ubah/ubh_guru.php?q="+nip+"&s=#",true);
        ajaxbos.send();
    }
function hapusdata(id_jenis_bayar){
    document.getElementById('id_jenis_bayar').value=id_jenis_bayar;
}
</script>