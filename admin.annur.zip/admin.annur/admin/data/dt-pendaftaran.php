<div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Data Pendaftaran Siswa Baru</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="keluar.php">
                               Keluar
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
<!-- MAIN -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            
                            <div class="content table-responsive table-full-width">
                                <table id="myTable" class="table table-hover table-striped">
                                    <thead>
                                        <th width="10px">No</th>
                                        <th>Id</th>
                                        <th>Password</th>
                                        <th>Nama Lengkap</th>
                                        <th>No Telepon</th>
                                        <th>Tingkatan</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = "SELECT * FROM ppdb ORDER BY id_daftar";
                                        $tampil = mysqli_query($connect,$query);
                                        $no = 1;
                                        while ($r = mysqli_fetch_array($tampil)){
                                            echo"
                                            <tr>
                                                <td>$no</td>
                                                <td style='text-transform:capitalize'>$r[id_daftar]</td>
                                                <td style='text-transform:capitalize'>$r[password]</td>
                                                <td style='text-transform:capitalize'>$r[nama_lengkap]</td>
                                                <td style='text-transform:capitalize'>$r[no_telpon]</td>
                                                <td style='text-transform:capitalize'>$r[tingkatan]</td>
                                                "; ?>
                                                <td> 
                                                <!-- Button trigger modal -->
                                                    <button type="button" class="btn btn-success pe-7s-eyedropper" value='<?php echo $r['id_daftar'];?>' onclick="viewdata(this.value)" data-toggle="modal" data-target="#viewdata"></i></button>
                                                </td>
                                            </tr>
                                            <?php
                                            $no++;}
                                            ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<!--****************** View Data ******************-->
<div class="modal fade" id="viewdata" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">View Pendaftaran</h4>
      </div>
      <div class="modal-body">
        <!-- general form elements -->
        <!-- form start -->
        <form role="form" method="" action="">
          <div class="box-body">
            <?php
                $no_pendaftaran = $_GET['no_pendaftaran'];
                $get = mysqli_query($koneksi,"SELECT * FROM siswa WHERE no_pendaftaran = $no_pendaftaran");
                while ($tampil=mysqli_fetch_array($get)) {
            ?>
            <div class="form-group">
              <label>Id</label>
              <input name="id" type="text" class="form-control" onkeypress="return isNumberKey(event)" maxlength="10" pattern=".{10,}" title="Masukkan Minimal 10 Karakter">
            </div>

            <div class="form-group">
              <label>Password</label>
              <input name="password" type="text" class="form-control" placeholder="Masukkan Nama Guru" maxlength="50" required="" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Kategori</label>
              <input name="kategori" type="text" class="form-control" placeholder="Masukkan Nama Guru" maxlength="50" required="" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Tahun Ajaran</label>
              <input name="tahun_ajaran" type="text" class="form-control" placeholder="Masukkan Nama Guru" maxlength="50" required="" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Tingkatan</label>
              <input name="tingkatan" type="text" class="form-control" placeholder="Masukkan Nama Guru" maxlength="50" required="" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Kelas</label>
              <input name="kelas" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Nama Lengkap</label>
              <input name="nama_lengkap" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Jenis Kelamin</label><br>
              <label><input type="radio" name="jenis_kelamin" value="Pria">Pria</label>
              <label><input type="radio" name="jenis_kelamin" value="Wanita">Wanita</label>
            </div>

            <div class="form-group">
              <label>Tempat Lahir</label>
              <input name="tempat_lahir" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Tanggal Lahir</label>
              <input name="tgl_lahir" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Nama Ayah</label>
              <input name="nama_ayah" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Tempat Lahir Ayah</label>
              <input name="tempat_lahir_ayah" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Tanggal Lahir Ayah</label>
              <input name="tgl_lahir_ayah" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Nama Ibu</label>
              <input name="nama_ibu" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Tempat Lahir Ibu</label>
              <input name="tempat_lahir_ibu" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Tanggal Lahir Ibu</label>
              <input name="tgl_lahir_ibu" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Pekerjaan Ayah</label>
              <input name="pekerjaan_ayah" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Pekerjaan Ibu</label>
              <input name="pekerjaan_ibu" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Pekerjaan Wali</label>
              <input name="pekerjaan_wali" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Pendidikan Ayah</label>
              <input name="pendidikan_ayah" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Pendidikan Ibu</label>
              <input name="pendidikan_ibu" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Daerah Ayah</label>
              <input name="daerah_ayah" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Daerah Ibu</label>
              <input name="daerah_ibu" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Alamat</label>
              <input name="alamat" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>RT</label>
              <input name="rt" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>RW</label>
              <input name="rw" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Kelurahan</label>
              <input name="kelurahan" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Kecamatan</label>
              <input name="kecamatan" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Kabupaten / Kota</label>
              <input name="kabupaten" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>No Telpon</label>
              <input name="no_telpon" type="text" class="form-control" style="text-transform: capitalize;">
            </div>

            <div class="form-group">
              <label>Pas Foto</label>
              <img src="<?php echo "file/".$d['nama_file']; ?>">
            </div>

            <div class="form-group">
              <label>Akte Kelahiran</label>
              <img src="<?php echo "file/".$d['nama_file']; ?>">
            </div>

            <div class="form-group">
              <label>Akte Keluarga</label>
              <img src="<?php echo "file/".$d['nama_file']; ?>">
            </div>
                <?php } ?>
            <br>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
          </div>
        </form>
        <!-- /.box -->
      </div>
    </div>
  </div>
</div>

<script>
    function ubahdata(nip){
    var ajaxbos = new XMLHttpRequest();
        ajaxbos.onreadystatechange= function(){
            if(ajaxbos.readyState==4 && ajaxbos.status==200){
                document.getElementById("dub").innerHTML= ajaxbos.responseText;
            }
        };
        ajaxbos.open("GET","ubah/ubh_guru.php?q="+nip+"&s=#",true);
        ajaxbos.send();
    }
function hapusdata(nip){
    document.getElementById('kdok').value=nip;
}
</script>