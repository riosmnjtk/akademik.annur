    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Wali Kelas</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="keluar.php">
                               Keluar
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
<!-- MAIN -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">
                                    <button type="button" class="btn btn-success pe-7s-add-user" data-toggle="modal" data-target="#tambahWakel"></i></button>
                                </h4>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>No</th>
                                        <th>Id Kelas</th>
                                        <th>NIP</th>
                                        <th>Nama Guru</th>
                                        <th>Nama Kelas</th>
                                        <th width="200px">Action</th>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = "SELECT `wali_kelas`.`id_kelas`, `wali_kelas`.`nip`, `guru`.`nm_guru`, `kelas`.`nama_kelas` FROM `guru` INNER JOIN `wali_kelas` ON `guru`.`nip` = `wali_kelas`.`nip` INNER JOIN `kelas` ON `kelas`.`id_kelas` = `wali_kelas`.`id_kelas`";
                                        $tampil = mysqli_query($connect,$query);
                                        $no = 1;
                                        while ($r = mysqli_fetch_array($tampil)){
                                            echo"
                                            <tr>
                                                <td>$no</td>
                                                <td>$r[id_kelas]</td>
                                                <td>$r[nip]</td>
                                                <td style='text-transform:capitalize'>$r[nm_guru]</td>
                                                <td style='text-transform:capitalize'>$r[nama_kelas]</td>
                                                <td> "; ?>
<!-- Button trigger modal -->
                                                <a href="ubah/ubh_admin.php?username=<?php echo $r['username']; ?>"><button type="button" class="btn btn-warning pe-7s-pen"></button></a>&nbsp;
                                                <button type="button" class="btn btn-danger" value='<?php echo $r['username'];?>' onclick="hapusdata(this.value)" data-toggle="modal" data-target="#hapusAdmin"><i class="pe-7s-trash"></i></button>
                                            </td>
                                        </tr>
                                        <?php
                                        $no++;}
                                        ?></tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- MODAL -->
  <!--****************** Tambah ******************-->
<div class="modal fade" id="tambahWakel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Tambah Wali Kelas</h4>
      </div>
      <div class="modal-body">
        <!-- general form elements -->
        <!-- form start -->
        <form role="form" method="POST" action="proses/prs_wakel.php">
          <div class="box-body">
            <div class="form-group">
                <label>Tahun</label>
                <select name="tahun" class="form-control select2" required style="width: 100%;">
                    <option value='' selected>- Pilih TS -</option>
                    <?php
                    $y=1;
                    for ($x = date('Y')+1; $x >= date('Y')-3;){
                        $y = $x--;
                        echo "<option value='$x/$y'>$x/$y</option>";
                    }
                    ?>
                </select>
            </div>
            <!-- /.box-body --><br>
            <div class="box-footer">
              <button name="tambahAdmin" type="submit" class="btn btn-primary">Tambah</button>
            </div>
          </div>
        </form>
        <!-- /.box -->
      </div>
    </div>
  </div>
</div>
<!--****************** Ubah ******************-->
<div class="modal fade" id="ubahAdmin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Ubah Admin</h4>
      </div>
      <div class="modal-body">
        <!-- general form elements -->
          <!-- form start -->
          <form role="form" method="POST" action="proses/prs_admin.php">
            <div class="box-body">
              <!-- Ubah Data -->
              <span id="dub"></span>
              <!-- End Ubah Data -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <button name="ubahAdmin" type="submit" class="btn btn-primary">Ubah</button>
            </div>
          </form>
        <!-- /.box -->
      </div>
    </div>
  </div>
</div>
<!-- MODAL HAPUS -->
        <div class="modal fade" id="hapusAdmin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Hapus Admin</h4>
                        </div>
                    <div class="modal-body">
                        <!-- general form elements -->
                        <!-- form start -->
                        <form role="form" method="POST" action="proses/prs_admin.php">
                            <div class="box-body">
                                Yakin ingin menghapus data?
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer">
                                <input type="hidden" id="kdok" name="id" value="">
                                <button name="hapusAdmin" type="submit" class="btn btn-primary">Hapus</button>
                            </div>
                        </form>
                            <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
<script>
    function ubahdata(username){
    var ajaxbos = new XMLHttpRequest();
        ajaxbos.onreadystatechange= function(){
            if(ajaxbos.readyState==4 && ajaxbos.status==200){
                document.getElementById("dub").innerHTML= ajaxbos.responseText;
            }
        };
        ajaxbos.open("GET","ubah/ubh_admin.php?q="+username+"&s=#",true);
        ajaxbos.send();
    }
function hapusdata(username){
    document.getElementById('kdok').value=username;
}
</script>