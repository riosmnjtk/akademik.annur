    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Guru</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="keluar.php">
                               Keluar
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
<!-- MAIN -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">
                                    <button type="button" class="btn btn-success pe-7s-add-user" data-toggle="modal" data-target="#tambahGuru"></i></button>
                                </h4>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table id="myTable" class="table table-hover table-striped">
                                    <thead>
                                        <th>No</th>
                                        <th>NIP</th>
                                        <th>Nama</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Jenis Guru</th>
                                        <th width="200px">Action</th>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = "SELECT * FROM guru ORDER BY nip";
                                        $tampil = mysqli_query($connect,$query);
                                        $no = 1;
                                        while ($r = mysqli_fetch_array($tampil)){
                                            echo"
                                            <tr>
                                                <td>$no</td>
                                                <td>$r[nip]</td>
                                                <td style='text-transform:capitalize'>$r[nm_guru]</td>
                                                <td style='text-transform:capitalize'>$r[jenkel_guru]</td>
                                                <td style='text-transform:capitalize'>$r[jenis_guru]</td>
                                                <td> "; ?>
<!-- Button trigger modal -->
                                                <button type="button" class="btn btn-warning" value='<?php echo $r['nip'];?>' onclick="ubahdata(this.value)" data-toggle="modal" data-target="#ubahGuru"><i class="glyphicon glyphicon-pencil"></i></button>&nbsp;
                                                <button type="button" class="btn btn-danger" value='<?php echo $r['nip'];?>' onclick="hapusdata(this.value)" data-toggle="modal" data-target="#hapusGuru"><i class="pe-7s-trash"></i></button>
                                            </td>
                                        </tr>
                                        <?php
                                        $no++;}
                                        ?></tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- MODAL -->
  <!--****************** Tambah ******************-->
<div class="modal fade" id="tambahGuru" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Tambah Guru</h4>
      </div>
      <div class="modal-body">
        <!-- general form elements -->
        <!-- form start -->
        <form role="form" method="POST" action="proses/prs_guru.php">
          <div class="box-body">
            <div class="form-group">
              <label>NIP</label>
              <input name="nip" type="text" class="form-control" placeholder="Masukkan NIP" required="" onkeypress="return isNumberKey(event)" maxlength="10" pattern=".{10,}" title="Masukkan Minimal 10 Karakter">
            </div>
            <div class="form-group">
              <label>Nama Guru</label>
              <input name="nmGuru" type="text" class="form-control" placeholder="Masukkan Nama Guru" maxlength="50" required="" style="text-transform: capitalize;">
            </div>
            <div class="form-group">
              <label>Jenis Kelamin</label><br>
              <label><input type="radio" name="jenis_kelamin" value="Pria">Pria</label>
              <label><input type="radio" name="jenis_kelamin" value="Wanita">Wanita</label>
            </div>
            <div class="form-group">
              <label>Jenis Guru</label>
              <select name="jenis_guru" class="form-control">
                <?php
                $query2 =  mysqli_query($connect,"SELECT jenis_guru FROM guru");
                ?>
                <option value='belum memilih' selected>-- Pilih Jenis Guru --</option>
                <option value="Guru Umum">Guru Umum</option>
                <option value="Tahfiz">Tahfiz</option>
                <option value="Tahsin">Tahsin</option>
              </select>
            </div>
            <!-- <div>
              <label>Password</label>
              <input type="password" class="form-control" name="pass" maxlength="20" placeholder="Masukkan Password" pattern=".{9,}" title="Masukkan Minimal 9 / Lebih Karakter" required="">
            </div> -->
            <!-- /.box-body --><br>
            <div class="box-footer">
              <button name="tambahGuru" type="submit" class="btn btn-primary">Tambah</button>
            </div>
          </div>
        </form>
        <!-- /.box -->
      </div>
    </div>
  </div>
</div>
<!--****************** Ubah ******************-->
<div class="modal fade" id="ubahGuru" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Ubah Admin</h4>
      </div>
      <div class="modal-body">
        <!-- general form elements -->
          <!-- form start -->
          <form role="form" method="POST" action="proses/prs_guru.php">
            <div class="box-body">
              <!-- Ubah Data -->
              <span id="dub"></span>
              <!-- End Ubah Data -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <button name="ubahGuru" type="submit" class="btn btn-primary">Ubah</button>
            </div>
          </form>
        <!-- /.box -->
      </div>
    </div>
  </div>
</div>
<!-- MODAL HAPUS -->
        <div class="modal fade" id="hapusGuru" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Hapus Guru</h4>
                        </div>
                    <div class="modal-body">
                        <!-- general form elements -->
                        <!-- form start -->
                        <form role="form" method="POST" action="proses/prs_guru.php">
                            <div class="box-body">
                                Yakin ingin menghapus data?
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer">
                                <input type="hidden" id="kdok" name="id">
                                <button name="hapusGuru" type="submit" class="btn btn-primary">Hapus</button>
                            </div>
                        </form>
                            <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
<script>
    function ubahdata(nip){
    var ajaxbos = new XMLHttpRequest();
        ajaxbos.onreadystatechange= function(){
            if(ajaxbos.readyState==4 && ajaxbos.status==200){
                document.getElementById("dub").innerHTML= ajaxbos.responseText;
            }
        };
        ajaxbos.open("GET","ubah/ubh_guru.php?q="+nip+"&s=#",true);
        ajaxbos.send();
    }
function hapusdata(nip){
    document.getElementById('kdok').value=nip;
}
</script>