<?php
include "../../koneksi.php";

//Proses Tambah
if(isset($_POST['tambahKelas'])){
  $idKelas = $_POST['idKelas'];
  $nmKelas  = $_POST['nmKelas'];
  //INSERT QUERY START
  $query1 = "insert into kelas values('$idKelas','$nmKelas')";
  //var_dump($query1);
  $sql1   = mysqli_query($connect,$query1);
  if ($sql1) {
      header("Location: ../index.php?hal=kelas");
    } else {
      header("Location: ../index.php?hal=kelas");
    }
}
//Proses Ubah
else if(isset($_POST['ubahKelas'])) {
  $idKelas = $_POST['idKelas'];
  $nmKelas  = $_POST['nmKelas'];
  //UPDATE QUERY START
  $query1 = "update kelas set nama_kelas='$nmKelas' where id_kelas='$idKelas'";
  $sql1 = mysqli_query($connect,$query1);
  if ($sql1) {
    header("Location: ../index.php?hal=kelas");
  } else {
    header("Location: ../index.php?hal=kelas");
  }
//UPDATE QUERY END
}
//Proses Hapus
else if(isset($_POST['hapusKelas'])) {
  $id = $_POST['id'];
  //DELETE QUERY START
  $query1 = "delete from kelas where id_kelas='$id'";
  $sql1 = mysqli_query($connect,$query1);
  if ($sql1) {
    header("Location: ../index.php?hal=kelas");
  } else {
    header("Location: ../index.php?hal=kelas");
  }
  exit;
}
?>