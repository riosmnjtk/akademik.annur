<?php
include "../../koneksi.php";

//Proses Tambah
if(isset($_POST['tambahGuru'])){
  $nip            = $_POST['nip'];
  $nmGuru         = $_POST['nmGuru'];
  $jenis_kelamin  = $_POST['jenis_kelamin'];
  $jenis_guru     = $_POST['jenis_guru'];
  //INSERT QUERY START
  $query1 = "insert into guru values('$nip','$nmGuru','$jenis_kelamin', '$jenis_guru')";
  //var_dump($query1);
  $sql1   = mysqli_query($connect,$query1);
  if ($sql1) {
      header("Location: ../index.php?hal=guru");
    } else {
      header("Location: ../index.php?hal=guru");
    }
}
//Proses Ubah
else if(isset($_POST['ubahGuru'])) {
  $nip            = $_POST['nip'];
  $nmGuru         = $_POST['nmGuru'];
  $jenis_kelamin  = $_POST['jenis_kelamin'];
  $jenis_guru     = $_POST['jenis_guru'];
  //UPDATE QUERY START
  $query1 = "update guru set nm_guru='$nmGuru', jenkel_guru='$jenis_kelamin', jenis_guru='$jenis_guru' where nip='$nip'";
  $sql1 = mysqli_query($connect,$query1);
  if ($sql1) {
    header("Location: ../index.php?hal=guru");
  } else {
    header("Location: ../index.php?hal=admin");
  }
//UPDATE QUERY END
}
//Proses Hapus
else if(isset($_POST['hapusGuru'])) {
  $id = $_POST['id'];
  //DELETE QUERY START
  $query1 = "delete from guru where nip='$id'";
  $sql1 = mysqli_query($connect,$query1);
  if ($sql1) {
    header("Location: ../index.php?hal=guru");
  } else {
    header("Location: ../index.php?hal=guru");
  }
  exit;
}
?>