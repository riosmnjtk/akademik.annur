<?php
include "../../koneksi.php";

//Proses Tambah
if(isset($_POST['tambahAdmin'])){
  $username = $_POST['username'];
  $nmAdmin     = $_POST['nmAdmin'];
  $password     = $_POST['pass'];
  //INSERT QUERY START
  $query1 = "insert into admin values('$username','$password','$nmAdmin')";
  //var_dump($query1);
  $sql1   = mysqli_query($connect,$query1);
  if ($sql1) {
      header("Location: ../index.php?hal=admin");
    } else {
      header("Location: ../index.php?hal=admin");
    }
}
//Proses Ubah
else if(isset($_POST['ubahAdmin'])) {
  $username   = $_POST['username'];
  $nama       = $_POST['nmAdmin'];
  $pass       = $_POST['pass'];
  //UPDATE QUERY START
  $query1 = "update admin set nama='$nama', password='$pass' where username='$username'";
  $sql1 = mysqli_query($connect,$query1);
  if ($sql1) {
    header("Location: ../index.php?hal=admin");
  } else {
    header("Location: ../index.php?hal=admin");
  }
//UPDATE QUERY END
}
//Proses Hapus
else if(isset($_POST['hapusAdmin'])) {
  $id = $_POST['id'];
  //DELETE QUERY START
  $query1 = "delete from admin where username='$id'";
  $sql1 = mysqli_query($connect,$query1);
  if ($sql1) {
    header("Location: ../index.php?hal=admin");
  } else {
    header("Location: ../index.php?hal=admin");
  }
  exit;
}
?>