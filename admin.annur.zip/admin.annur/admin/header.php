<!-- Mengatur Tanggal Indonesia -->
<?php 
include "../koneksi.php";
session_start();
if(!isset($_SESSION['username'])){
    ?>
    <script >
        alert("Anda harus login terlebih dahulu");
        document.location="../index.php";
    </script>
    <?php
}
date_default_timezone_set('Asia/Jakarta');
function tglIndonesia($str){
    $tr   = trim($str);
    $str    = str_replace(array('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'), array('Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum\'at', 'Sabtu', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'), $tr);
    return $str;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../img/annur.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Admin Annur</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <!-- DATA TABLE -->
    <link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="assets/css/sweetalert.css">
</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="assets/img/sidebar-5.jpg">

    <!--
        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag
    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                    <img width="200px" src="../img/annur.png" alt="Logo Annur">
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="index.php?hal=beranda">
                        <i class="pe-7s-monitor"></i>
                        <p>Beranda</p>
                    </a>
                </li>

                <li class="active">
                    <a href="index.php?hal=pendaftaran">
                        <i class="pe-7s-id"></i>
                        <p>Pendaftaran</p>
                    </a>
                </li>

                <li class="active">
                    <a href="index.php?hal=jenis_bayar">
                        <i class="pe-7s-bookmarks"></i>
                        <p>Jenis Bayar</p>
                    </a>
                </li>

                <li class="active">
                    <a href="index.php?hal=pembayaran_pendaftaran">
                        <i class="pe-7s-cash"></i>
                        <p>Bayar Pendaftaran</p>
                    </a>
                </li>

                <!--<li class="active" hidden>
                    <a href="index.php?hal=admin">
                        <i class="pe-7s-user"></i>
                        <p>Admin</p>
                    </a>
                </li>

                <li class="active">
                    <a href="index.php?hal=guru">
                        <i class="pe-7s-study"></i>
                        <p>Guru</p>
                    </a>
                </li>

                <li class="active">
                    <a href="index.php?hal=kelas">
                        <i class="pe-7s-study"></i>
                        <p>Kelas</p>
                    </a>
                </li>

                <li class="active">
                    <a href="index.php?hal=wakel">
                        <i class="pe-7s-study"></i>
                        <p>Wali Kelas</p>
                    </a>
                </li>-->

            </ul>
    	</div>
    </div>