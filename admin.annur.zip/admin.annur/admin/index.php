<?php
  include 'header.php';

  //Include file header.php
  //include 'header.php';
  //cek session, jika tidak ada, maka alihkan ke hal utama
  if(isset($_GET['hal'])){
      switch($_GET['hal']){
          case 'beranda'          : include 'beranda.php'; break;
          case 'admin'            : include 'data/dt-admin.php'; break;
          case 'guru'             : include 'data/dt-guru.php'; break;
          case 'kelas'            : include 'data/dt-kelas.php'; break;
          case 'wakel'            : include 'data/dt-wakel.php'; break;
          case 'pendaftaran'      : include 'data/dt-pendaftaran.php'; break;
          case 'jenis_bayar'      : include 'data/dt-jenisbayar.php'; break;
          default : include '404.php';
      }
  }else{
      include 'beranda.php';
  }
  //Include file footer.php
  include 'footer.php';

?>
