<?php
  include "../../koneksi.php";
  
  $tampil = mysqli_query($connect,"SELECT * FROM guru where nip='".$_GET['q']."'");
  //var_dump($tampil);    
  $r = mysqli_fetch_array($tampil);
?>
<div class="form-group">
  <label>NIP</label>
  <input name="nip" type="text" class="form-control" value="<?php echo $r['nip']; ?>" required="" onkeypress="return isNumberKey(event)" maxlength="10" pattern=".{10,}"  readonly>
</div>
<div class="form-group">
  <label>Nama Guru</label>
  <input name="nmGuru" type="text" class="form-control" value="<?php echo $r['nm_guru']; ?>" maxlength="50" required="" style="text-transform: capitalize;">
</div>
<div class="form-group">
  <label>Jenis Kelamin</label><br>
  <label><input type="radio" name="jenis_kelamin" value="Pria" <?php if($r['jenkel_guru']=='Pria') echo 'checked'?>>Pria</label>
  <label><input type="radio" name="jenis_kelamin" value="Wanita" <?php if($r['jenkel_guru']=='Wanita') echo 'checked'?>>Wanita</label>
</div>
<div class="form-group"> 
  <label>Jenis Guru</label>
  <select name="jenis_guru" class="form-control">
    <option value='belum memilih' selected>-- Pilih Jenis Guru --</option>
    <option value="Guru Umum">Guru Umum</option>
    <option value="Tahfiz">Tahfiz</option>
    <option value="Tahsin">Tahsin</option>
  </select>
</div>