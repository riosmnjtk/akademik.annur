<?php
  include "../../koneksi.php";
  
  $tampil = mysqli_query($connect,"SELECT * FROM admin where username='".$_GET['q']."'");
  //var_dump($tampil);    
  $r = mysqli_fetch_array($tampil);
?>
<div class="form-group">
  <label>Username</label>
  <input name="username" type="text" class="form-control" value="<?php echo $r['username'];?>" >
</div>
<div class="form-group">
  <label>Nama Admin</label>
  <input name="nmAdmin" type="text" class="form-control" value="<?php echo $r['nama'];?>" maxlength="20" required=""  style="text-transform: capitalize;">
</div>
<div>
  <label>Password</label>
  <input type="password" class="form-control" name="pass" maxlength="20" value="<?php echo $r['password'];?>" pattern=".{9,}" title="Masukkan Minimal 9 / Lebih Karakter" required="">
</div>