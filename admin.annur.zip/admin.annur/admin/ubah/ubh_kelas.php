<?php
  include "../../koneksi.php";
  
  $tampil = mysqli_query($connect,"SELECT * FROM kelas where id_kelas='".$_GET['q']."'");
  //var_dump($tampil);    
  $r = mysqli_fetch_array($tampil);
?>
<div class="form-group">
  <label>ID Kelas</label>
  <input name="idKelas" type="text" class="form-control" value="<?php echo $r['id_kelas']; ?>"  readonly>
</div>
<div class="form-group">
  <label>Nama Kelas</label>
  <input name="nmKelas" type="text" class="form-control" value="<?php echo $r['nama_kelas']; ?>" maxlength="20" required="" style="text-transform: capitalize;">
</div>