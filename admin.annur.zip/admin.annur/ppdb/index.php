<?php
  include 'header.php';

  //Include file header.php
  //include 'header.php';
  //cek session, jika tidak ada, maka alihkan ke hal utama
  if(isset($_GET['hal'])){
      switch($_GET['hal']){
          case 'beranda'   : include 'beranda.php'; break;
          case 'upload'     : include 'data/dt_upload.php'; break;
          default : include '404.php';
      }
  }else{
      include 'beranda.php';
  }
  //Include file footer.php
  include 'footer.php';

?>
