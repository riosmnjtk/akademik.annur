    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Upload Bukti Bayar</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="keluar.php">
                               Keluar
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
<!-- MAIN -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <form role="form" method="POST" action="proses/prs_upload.php" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label>Kode Pembayaran</label>
                                <input name="kdBayar" type="text" class="form-control" placeholder="Masukkan Kode Pembayaran">
                            </div>
                            <div class="form-group">
                                <label>Upload Bukti Pembayaran</label>
                                <input name="file" type="file" class="form-control">
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer">
                                <button name="upload" type="submit" class="btn btn-primary">Upload</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
<!-- MODAL HAPUS -->
        <div class="modal fade" id="hapusAdmin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Hapus Admin</h4>
                        </div>
                    <div class="modal-body">
                        <!-- general form elements -->
                        <!-- form start -->
                        <form role="form" method="POST" action="proses/prs_admin.php">
                            <div class="box-body">
                                Yakin ingin menghapus data?
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer">
                                <input type="hidden" id="kdok" name="id" value="">
                                <button name="hapusAdmin" type="submit" class="btn btn-primary">Hapus</button>
                            </div>
                        </form>
                            <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
<script>
function hapusdata(username){
    document.getElementById('kdok').value=username;
}
</script>