<?php
include "../../koneksi.php";

if(isset($_POST['upload'])){
  $kdBayar                = $_POST['kdBayar'];
  $ekstensi_diperbolehkan = array('jpg', 'png', 'pdf');
  $nama                   = $_FILES['file']['name'];
  $x                      = explode('.', $nama);
  $ekstensi               = strtolower(end($x));
  $ukuran                 = $_FILES['file']['size'];
  $file_tmp               = $_FILES['file']['tmp_name'];

  
  if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
    if($ukuran < 1044070){
      move_uploaded_file($file_tmp, 'file/'.$nama);
      $query = mysqli_query($connect,"UPDATE ppdb set namafile='$nama', kodepembayaran='$kdBayar' WHERE id_daftar='PPDB000001' ");
      //var_dump($query);
      if($query){
        header("Location: ../index.php?hal=beranda");
      }else{
        header("Location: ../index.php?hal=upload");
      }
    }else{
      echo 'UKURAN FILE TERLALU BESAR';
    }
  }else{
    echo 'EKSTENSI FILE YANG DIGUNAKAN TIDAK DIPERBOLEHKAN';
  }
}
?>